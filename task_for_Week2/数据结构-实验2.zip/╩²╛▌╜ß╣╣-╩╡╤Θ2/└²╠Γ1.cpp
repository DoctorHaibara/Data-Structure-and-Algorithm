#include<iostream>
using namespace std;

struct ListNode
{
    double val;
    ListNode *next;
     ListNode() : val(0), next(NULL) {}
     ListNode(int x) : val(x), next(NULL) {}
     ListNode(int x, ListNode *next) : val(x), next(next) {}
};

ListNode* create(int n)
{
	ListNode *dummy = NULL;
	dummy = new ListNode;
	ListNode *pre = dummy;
	for (int i = 0; i < n; i++)
	{
		ListNode *p = new ListNode;
		cin >> p->val;
		pre->next = p;
		pre = pre->next;
	}
	return dummy->next;
}
void print(ListNode* head)
{
	while (head)
	{
		if (head->next == NULL)
			cout << head->val<<"-> NULL";
		else
			cout << head->val << "-> ";
		head = head->next;
	}
	cout << endl;
}
int main()
{
	int n;
	cin >> n;
	ListNode *head = create(n);
	print(head);
	system("pause");
	return 0;
}



